# TUJP Connect Card — Daan Grasveld

- `index.html` — the landing page
- `daan-grasveld.vcf` — the downloadable contact card for the CTA button
- `jungle-blocks.jpg`, `opzuid-logo.png`, `tujp-logotype.svg`, `tujp-logomark.svg` — shared assets, self-contained in this folder

## Current status

- ✅ HubSpot form is live (same portal/form as Dries's card)
- ✅ Vimeo video is embedded
- ✅ Jungle Blocks® photo and TUJP logos are in place
- ✅ OPZuid / EU co-financing badge is in the footer
- ⏳ **Daan's photo** — add `daan-photo.jpg` to this folder, then in `index.html` replace
  `<div class="avatar">DG</div>` with `<img src="daan-photo.jpg" alt="Daan Grasveld">` inside `.avatar`
  (see the TODO comment right above it). Match Dries's photo framing: square crop, ~560×560px.

See the repo root `README.md` for how this folder is deployed and how to add another colleague.
