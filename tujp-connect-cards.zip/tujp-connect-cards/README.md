# TUJP Connect Cards

Digital business cards for The Urban Jungle Project — one folder per person, each deployable as its own Netlify site.

```
tujp-connect-cards/
├── dries/     → Dries Grasveld's card
├── daan/      → Daan Grasveld's card
├── hans/      → Hans Mathijsse's card
└── README.md  → this file
```

Each person's folder is **fully self-contained**: its own `index.html`, its own `.vcf`, and its own copies of the shared assets (Jungle Blocks® photo, TUJP logos, OPZuid badge). Nothing is shared *between* folders — that's deliberate, so one person's site can be deployed, redeployed, or torn down without ever touching anyone else's.

## Why one repo, not one repo per person

A single GitHub repo holding all the folders means you only manage one place for edits (a new photo, a copy tweak, a new form field). Netlify then reads **one folder** of this repo per site, via that site's **Base directory** setting — so multiple independent Netlify sites can all deploy from the same repo, each looking at its own folder.

## Setting up a site for a folder

1. Push/upload this whole `tujp-connect-cards` folder to a GitHub repo (e.g. `tujp-connect-cards`), as the repo root.
2. In Netlify: **Add new site → Import an existing project** → pick that repo.
3. Set **Base directory** to the person's folder name (e.g. `dries`, `daan` or `hans`). Leave **Build command** empty — each folder's `netlify.toml` handles the rest.
4. Rename the site (Site configuration → General → Change site name) to something like `tujp-connectcard-<firstname><lastname>`.
5. Repeat step 2–4 for each additional folder/person — same repo, a new Netlify site each time, each pointed at its own Base directory.

Once a site is linked to the repo this way, **any push to `main` that touches that person's folder auto-redeploys their site** — no more manual zip uploads.

## Adding a new colleague

1. Duplicate an existing folder (e.g. `cp -r dries newperson`).
2. In `newperson/index.html`: update the `<title>`, the contact block (name, role, email, phone), and the CTA's `href`/`download` filename.
3. Rename `dries-grasveld.vcf` to `newperson-name.vcf` and edit its fields (`FN`, `TITLE`, `EMAIL`, `TEL`, `NOTE`).
4. Add their photo as `<name>-photo.jpg` and wire it into the `.avatar` div (see the TODO comment there).
5. Push to GitHub, then follow "Setting up a site for a folder" above to give them their own Netlify site.

## Custom subdomains

Each site can additionally get a friendly subdomain, e.g. `connect.theurbanjungleproject.com` for Dries, `daan.connect.theurbanjungleproject.com` for Daan, `hans.connect.theurbanjungleproject.com` for Hans — via that site's **Domain management → Add a domain**, then a CNAME record with your DNS provider. Full walkthrough is in each folder's own history in this project's chat log; the short version:

- Netlify gives you a CNAME target after you add the domain
- Add a `CNAME` record at your DNS provider: name = the subdomain part, value = that target
- SSL is provisioned automatically once DNS resolves

## Event tracking / NFC

Share a card's link with a query parameter, e.g. `https://connect.theurbanjungleproject.com/?event=provada26`. Each `index.html` passes that value to a hidden HubSpot form field named `event_source` automatically, once that field exists on the form — so you can see in HubSpot which event/channel a lead came from, regardless of whose card they scanned. Write each person's final URL to their own NFC chip once their site is live.
