# TUJP Connect Card — Hans Mathijsse

- `index.html` — the landing page
- `hans-mathijsse.vcf` — the downloadable contact card for the CTA button
- `jungle-blocks.jpg`, `opzuid-logo.png`, `tujp-logotype.svg`, `tujp-logomark.svg` — shared assets, self-contained in this folder

## Current status

- ✅ HubSpot form is live (same portal/form as Dries's card)
- ✅ Vimeo video is embedded
- ✅ Jungle Blocks® photo and TUJP logos are in place
- ✅ OPZuid / EU co-financing badge is in the footer
- ⏳ **Hans's photo** — add `hans-photo.jpg` to this folder, then in `index.html` replace
  `<div class="avatar">HM</div>` with `<img src="hans-photo.jpg" alt="Hans Mathijsse">` inside `.avatar`
  (see the TODO comment right above it). Match Dries's photo framing: square crop, ~560×560px.

## Note on contact details

Hans is listed as **Advisory Board**, with his own email (`hans@matthijsse.de`) rather than a
`@theurbanjungleproject.com` address — his `.vcf` and the page reflect that as given. Let me know
if he should actually get a TUJP email address instead.

See the repo root `README.md` for how this folder is deployed and how to add another colleague.
